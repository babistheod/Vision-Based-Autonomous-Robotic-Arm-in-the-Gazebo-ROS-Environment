#!/usr/bin/env python


import sys
import numpy as np
import copy 
import traceback

import asyncio

import pdb

import math3d

import rospy
import moveit_commander
import moveit_msgs.msg

import threading

from std_srvs.srv import Empty
from geometry_msgs.msg import Twist, Pose2D, Pose, PoseStamped
from sensor_msgs.msg import Image
from std_msgs.msg import Header
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint

from ur5_pick_place_gazebo.srv import RobotCmd, RobotCmdRequest, RobotCmdResponse

from pkg_utilts import RobotCommanderCmd, RobotCommanderStatus, to_m3d_transform, to_geometry_msgs_pose

# pdb.set_trace()

class GripperCommander:
    def __init__(self, num_grippers=9):# num_grippers=9
        self.num_grippers = num_grippers
        self.grippers = list(range(num_grippers))

    async def actor(self, cmd, num):
        try:
            srv_name = '/ur5/vacuum_gripper{}/{}'.format(num, cmd)
            print(srv_name)
            rospy.wait_for_service(srv_name, timeout=2)
            switch = rospy.ServiceProxy(srv_name, Empty)
            res = switch()
            print(res)
        except Exception as ex:
            print(ex.args)
            traceback.print_exc()


    # async def turn_on(self, num):
    #     self.actor("on", str(num))

    # async def turn_off(self, num):
    #     self.actor("off", str(num))

    async def turn_on_srv_caller(self, num_grippers=9):
        grippers = list(range(num_grippers))
        on_list = num_grippers * ["on"] # make a list with num_grippers times "on"
        await asyncio.gather(*map(self.actor, on_list, grippers))

    async def turn_off_srv_caller(self, num_grippers=9):
        grippers = list(range(num_grippers))
        off_list = num_grippers * ["off"] # make a list with num_grippers times "on"
        await asyncio.gather(*map(self.actor, off_list, grippers))

    def turn_all_grippers_on(self):
        try:
            result = asyncio.run(self.turn_on_srv_caller())
            print("result: ", result)
            return True
        except Exception as ex:
            print(ex.args)
            traceback.print_exc()
            return False

    def turn_all_grippers_off(self):
        try:
            result = asyncio.run(self.turn_off_srv_caller())
            print("result: ", result)
            return True
        except Exception as ex:
            print(ex.args)
            traceback.print_exc()
            return False




class RobotCommander(GripperCommander):
    def __init__(self):
        super(GripperCommander, self).__init__()

        # Initialize the move_group API
        moveit_commander.roscpp_initialize(sys.argv)

        # Initialize the move group for the ur5_arm
        self.arm = moveit_commander.MoveGroupCommander('manipulator')

        # Get the name of the end-effector link
        # get_pose_reference_frame(self):
        # self.end_effector_link = self.arm.get_end_effector_link()

        # Set the reference frame for pose targets
        # reference_frame = "/base_link"

        # Set the ur5_arm reference frame accordingly
        # self.arm.set_pose_reference_frame(reference_frame)
        # self.default_ref_frame = self.arm.get_pose_reference_frame()
        self.arm.set_pose_reference_frame("base_link")
        # self.arm.set_end_effector_link()

        self.default_planning_frame = self.arm.get_planning_frame()
        self.default_ref_frame = self.arm.get_pose_reference_frame()
        self.default_ee_frame = self.arm.get_end_effector_link()

        rospy.loginfo("self.default_planning_frame: " + self.default_planning_frame)
        rospy.loginfo("self.default_ref_frame: " + self.default_ref_frame)
        rospy.loginfo("self.default_ee_frame: " + self.default_ee_frame)

        # Allow replanning to increase the odds of a solution
        self.arm.allow_replanning(True)

        # Allow some leeway in position (meters) and orientation (radians)

        self.arm.set_goal_position_tolerance(0.01)
        self.arm.set_goal_orientation_tolerance(0.1)
        
        # self.arm.set_planner_id("RRTConnectkConfigDefault")

        # self.arm.set_planning_time(10)
        self.default_max_acceleration_scaling_factor = 0.1
        self.default_max_velocity_scaling_factor = 0.1
        
        self.tracking_max_acceleration_scaling_factor = 0.051
        self.tracking_max_velocity_scaling_factor = 0.051

        self.arm.set_max_acceleration_scaling_factor(self.default_max_velocity_scaling_factor)
        self.arm.set_max_velocity_scaling_factor(self.default_max_velocity_scaling_factor)

        self.arm.clear_path_constraints()


        self.home_pose = Pose()
        self.home_pose.position.x = 0.450000000
        self.home_pose.position.y = 0.00000000
        self.home_pose.position.z = 0.250000000
        self.home_pose.orientation.x = 0.0000000
        self.home_pose.orientation.y = 0.7070000000
        self.home_pose.orientation.z = 0.00000000
        self.home_pose.orientation.w = 0.7070000000


        try:
            cam_pose = self.arm.get_current_pose(end_effector_link = "camera_link_optical" )
            ee_pose = self.arm.get_current_pose(end_effector_link = "ee_link" )
            
            print("cam_pose: ", cam_pose)
            print("ee_pose: ", ee_pose)

            # print("going to home")
            # # bring robot to home position
            # self.arm.go(joints=[
            #     0.0,
            #     -1.57,
            #     1.57,
            #     -1.57,
            #     -1.57,
            #     0.0
            # ])


            # plan, fraction = self.arm.compute_cartesian_path(
            #     [self.home_pose], 
            #     0.02, 
            #     0.0, 
            #     True
            # )
            # print(plan)
            # self.arm.execute(plan)
            
            # x, y, z, qx, qy, qz, qw
            # self.arm.set_pose_target(
            #     [
            #         self.home_pose.position.x,
            #         self.home_pose.position.y,
            #         self.home_pose.position.z,
            #         self.home_pose.orientation.x,
            #         self.home_pose.orientation.y,
            #         self.home_pose.orientation.z,
            #         self.home_pose.orientation.w,
            #     ],

            #     end_effector_link="ee_link"
            # )

            # self.arm.go()
                        
            self.arm.clear_pose_targets()


        except Exception as ex:
            rospy.loginfo(ex.args)
            traceback.print_exc()

        self.track_obj_cb_lock = threading.Lock()

        self.task_completion_event = threading.Event()
        self.task_completion_event.clear()

        self.send_commands = threading.Event()
        self.send_commands.clear()

        self.z_pre_grip = 0.05
        self.z_pick = -0.065#-0.0525
        self.inc_dist = 0.0251 # 0.05

        self.error_x = 0
        self.error_y = 0

        self.offset_x = 0   #px
        self.offset_y = 0 #px 200

        self.track_obj_srv = rospy.Service('/robot_cmd', RobotCmd, self.robot_cmd_cb)
        rospy.loginfo("/robot_cmd srv is ready ...")

        # self.track_obj = rospy.Subscriber('asdasdasdasdas', Pose2D, self.track_obj_cb, queue_size=1)
        
        # self.commanding_timer = rospy.Timer(rospy.Rate(10), self.alignment_commander)



    def robot_cmd_cb(self, req):
        # ALIGN
        # PICK
        # PLACE
        # HOME
        try:
            if req.cmd == RobotCommanderCmd.ALIGN:
                self.arm.set_max_acceleration_scaling_factor(self.tracking_max_acceleration_scaling_factor)
                self.arm.set_max_velocity_scaling_factor(self.tracking_max_velocity_scaling_factor)

                print("clearing \"task_completion_event\" event ...")
                self.task_completion_event.clear()

                self.send_commands.set()
                self.arm.set_end_effector_link("camera_link_optical")

                self.track_obj = rospy.Subscriber('/error_loc_px', Pose2D, self.track_obj_cb, queue_size=1)

                self.commanding_timer = rospy.Timer(rospy.Duration(0.025), self.alignment_commander)

                print("waiting for \"task_completion_event\" to set")
                self.task_completion_event.wait()

                self.track_obj.unregister()
                self.commanding_timer.shutdown()

                self.arm.set_end_effector_link(self.default_ee_frame)
                self.arm.set_pose_reference_frame(self.default_ref_frame)

                return RobotCommanderStatus.ALIGNED

            elif req.cmd == RobotCommanderCmd.PICK:                
                self.pick_obj(req.reqPose)

                self.arm.set_max_acceleration_scaling_factor(self.default_max_velocity_scaling_factor)
                self.arm.set_max_velocity_scaling_factor(self.default_max_velocity_scaling_factor)

                return RobotCommanderStatus.PICKED

            elif req.cmd == RobotCommanderCmd.PLACE:                
                self.place_obj(req.reqPose)

                self.arm.set_max_acceleration_scaling_factor(self.default_max_velocity_scaling_factor)
                self.arm.set_max_velocity_scaling_factor(self.default_max_velocity_scaling_factor)

                return RobotCommanderStatus.PLACED

            elif req.cmd == RobotCommanderCmd.HOME:                
                self.go_home(step=2)

                self.arm.set_max_acceleration_scaling_factor(self.default_max_velocity_scaling_factor)
                self.arm.set_max_velocity_scaling_factor(self.default_max_velocity_scaling_factor)

                return RobotCommanderStatus.AT_HOME


        except Exception as ex:
                print(ex.args)
                traceback.print_exc()

                return RobotCommanderStatus.FAILED


    def go_home(self, step=1):
        # bring robot to home position
        print("going to home")

        if step == 2:
            self.arm.go(joints=[
                0.0,
                -1.57,
                2.356125,
                -2.356125,
                -1.57,
                0.0
            ])


        plan, fraction = self.arm.compute_cartesian_path(
            [self.home_pose], 
            0.02, 
            0.0, 
            True
        )
        print(plan)
        self.arm.execute(plan)

    def alignment_commander(self, timer):
        # with self.track_obj_cb_lock:
        #     self.error_x = msg.x
        #     self.error_y = msg.y
        curr_cam_pose_stamped = self.arm.get_current_pose(end_effector_link = "camera_link_optical" )

        if np.abs(self.error_x) + self.offset_x <  25 and np.abs(self.error_y) + self.offset_y <  25 and curr_cam_pose_stamped.pose.position.z <= self.z_pre_grip:
            print("stopping robot")
            print("setting \"task_completion_event\" event ...")
            self.task_completion_event.set()
            self.send_commands.clear()
            self.arm.stop()
            self.arm.clear_pose_targets()
                # return


    def track_obj_cb(self, msg):
        try:
            with self.track_obj_cb_lock:
                self.error_x = msg.x
                self.error_y = msg.y


            direc_vec = np.array([
                self.error_x + self.offset_x, 
                self.error_y + self.offset_y
            ])
            error_norm = np.linalg.norm(direc_vec)

            direc_vec /= error_norm

            x_cam_inc, y_cam_inc = self.inc_dist * direc_vec

            # for saturation of inc
            # if error_norm > 100:
            #     x_cam_inc, y_cam_inc = self.inc_dist * direc_vec
            # elif error_norm <= 100:
            #     x_cam_inc, y_cam_inc =  0.005 * error_norm * direc_vec

            inc_pose_cam = Pose()
            inc_pose_cam.position.x = x_cam_inc
            inc_pose_cam.position.y = y_cam_inc
            
            inc_pose_cam.orientation.w = 1

            # bring the pose in cam in world pose
            curr_cam_pose_stamped = self.arm.get_current_pose(end_effector_link = "camera_link_optical" )
            curr_cam_pose = curr_cam_pose_stamped.pose

            curr_cam_pose_m3d = to_m3d_transform(curr_cam_pose)
            inc_cam_m3d = to_m3d_transform(inc_pose_cam)

            inc_pose_base_m3d = curr_cam_pose_m3d * inc_cam_m3d

            inc_pose_base = to_geometry_msgs_pose(inc_pose_base_m3d)

            # with tracking also keep going near to object
            if curr_cam_pose_stamped.pose.position.z > self.z_pre_grip:
                # print("decrementing in z")
                inc_pose_base.position.z -= self.inc_dist#self.z_pre_grip


            # print("self.error_x: {}, self.error_y: {}, x_cam_inc: {}, y_cam_inc: {}".format(self.error_x, self.error_y,x_cam_inc, y_cam_inc))


            if self.send_commands.is_set():
                self.arm.set_end_effector_link("camera_link_optical")
                plan, fraction = self.arm.compute_cartesian_path(
                    [inc_pose_base], # [curr_pose], 
                    0.02, 
                    0.0, 
                    True
                )
                # print(plan)
                self.arm.clear_pose_targets()
                self.arm.execute(plan, wait = False)


        except Exception as ex:
            traceback.print_exc()
            print(ex.args)

    
    def pick_obj(self, reqPose):
        try:
            curr_ee_pose_stamped = self.arm.get_current_pose(end_effector_link = "ee_link" )
            pick_pose = copy.deepcopy(curr_ee_pose_stamped.pose)

             # as alignment was done according to the center of the camera frame so, moveing 0.055m in x-axis of robot to align to the ee
            pick_pose.position.x += 0.055
            pick_pose.position.z = self.z_pick #-0.0525

            self.arm.set_end_effector_link("ee_link")
            plan, fraction = self.arm.compute_cartesian_path(
                [pick_pose], # [curr_pose], 
                0.02, 
                0.0, 
                True
            )
            # print(plan)
            self.arm.execute(plan, wait = True)

            # tries 5 time to pick the object
            # for ii in range(5):
            # rospy.loginfo("{} try to grip".format(ii))
            is_picked = self.turn_all_grippers_on()
                # if is_picked:
                #     print("gripped")
                #     break

            post_pick_pose = copy.deepcopy(curr_ee_pose_stamped.pose)
            post_pick_pose.position.z = 0.125
            plan, fraction = self.arm.compute_cartesian_path(
                [post_pick_pose], # [curr_pose], 
                0.02, 
                0.0, 
                True
            )
            # print(plan)
            self.arm.execute(plan, wait = True)
            return RobotCommanderStatus.PICKED

        except Exception as ex:
            print(ex.args)
            traceback.print_exc()
            return RobotCommanderStatus.FAILED


    def place_obj(self, reqPose):
        try:
            # get latest pose for keeping the oreintation same
            curr_ee_pose_stamped = self.arm.get_current_pose(end_effector_link = "ee_link" )
            pre_place_pose = copy.deepcopy(reqPose)

            pre_place_pose.position.z += 0.1

            pre_place_pose.orientation = curr_ee_pose_stamped.pose.orientation

            print("approaching pre_place_pose")
            self.arm.set_end_effector_link("ee_link")
            plan, fraction = self.arm.compute_cartesian_path(
                [pre_place_pose], # [curr_pose], 
                0.02, 
                0.0, 
                True
            )
            # print(plan)
            self.arm.execute(plan, wait = True)



            place_pose = copy.deepcopy(reqPose)

            place_pose.orientation = curr_ee_pose_stamped.pose.orientation

            print("approaching place_pose")
            self.arm.set_end_effector_link("ee_link")
            plan, fraction = self.arm.compute_cartesian_path(
                [place_pose], # [curr_pose], 
                0.02, 
                0.0, 
                True
            )
            # print(plan)
            self.arm.execute(plan, wait = True)


            self.turn_all_grippers_off()


            # curr_ee_pose_stamped = self.arm.get_current_pose(end_effector_link = "ee_link" )
            # post_place_pose = copy.deepcopy(curr_ee_pose_stamped.pose)


            # post_place_pose.position.z += 0.2

            print("approaching post_place_pose")
            self.arm.set_end_effector_link("ee_link")
            plan, fraction = self.arm.compute_cartesian_path(
                [self.home_pose], # [curr_pose], 
                0.02, 
                0.0, 
                True
            )
            # print(plan)
            self.arm.execute(plan, wait = True)



            return RobotCommanderStatus.PLACED

        except Exception as ex:
            print(ex.args)
            traceback.print_exc()
            return RobotCommanderStatus.FAILED



if __name__ == "__main__":
    rospy.init_node("robot_commander", anonymous=False)
    rc = RobotCommander()

    rospy.spin()

